import Foundation

class LotteryDream {
  
  let numberOfPeople = 14
  
  var costPerPerson = 200 {
    
    didSet {
      
      print("didSet: costPerPerson")
    }
  }
  
  var totalCost: Int {
    
    get {
      
      return costPerPerson * numberOfPeople
    }
    
    set {
      
      costPerPerson = newValue / numberOfPeople
    }
  }
}

class AstridsLotteryDream: LotteryDream {
  
  override var totalCost: Int {
    
    willSet{
      
      print("willSet: totalCost will be \(newValue), and it is now \(totalCost)")
    }
    
    didSet{
      
      print("didSet: totalCost is now \(totalCost), and it was \(oldValue)")
    }
  }
  
  override var costPerPerson: Int {
    
    didSet {
      
      if costPerPerson >= 200000 {
        costPerPerson = 199999
        print(" 🙄 🙄 🙄Astrid is out of her mind 🙄 🙄 🙄")
      }
    }
  }
}

let astridsDayDream = AstridsLotteryDream()

astridsDayDream.totalCost = 28000000000

astridsDayDream.costPerPerson
